// Case 5 - Sistem Seleksi Beasiswa

// Input: IPK, penghasilan orang tua, jumlah tanggungan, dan prestasi.
// Syarat utama: IPK >= 3,50 dan penghasilan orang tua <= Rp5.000.000.
// Beasiswa Prestasi Unggul: IPK >= 3,75 dan memiliki prestasi.
// Beasiswa Reguler: IPK >= 3,50, penghasilan <= Rp5.000.000, tanggungan >= 3.
// Selain kondisi tersebut: tidak dapat beasiswa
// Prestasi: 1 = Tidak ada, 2 = Fakultas, 3 = Universitas, 4 = Nasional.
// Fokus: if, if-else, nested-if, dan switch-case.

#include <iostream>
#include <string>

using namespace std;

int main()
{

    // Kita bikin variable dulu ygy
    double IPK;                 // Pake double biar bisa di isi pake koma / titik
    double penghasilanOrangTua; // Pake double biar bisa di isi pake koma / titik
    int tanggungan;
    int prestasi;

    // Masuk ke program nya ni
    // Kita kasih header nya dulu biar keren sikit
    cout << endl;
    cout << "==================================" << endl;
    cout << "    Sistem Seleksi Mahasiswa" << endl;
    cout << "==================================" << endl;
    cout << endl;

    // Input IPK
    do
    {                                       // Kenapa disini aku pake do while? karena disini aku nemu masalah, gimana kalau user memasukkan ipk yang ngga masuk akal? apakah cuman diberi pesan itu ngga valid? ya ngga dong berati sama aja aku mematikan program nya sendiri, jadi disini fungsi do while / looping nya itu memaksa user input IPK yang valid, jika salah maka akan ulang terus terusan.
        cout << "Masukkan IPK : " << flush; // Meminta IPK
        cin >> IPK;                         // Input IPK

        if (IPK < 0.00 || IPK > 4.00) // Ini yang aku sebutin tadi di baris ke 32, jika IPK yang di input ga valid maka akan muncul pesan error
        {
            cout << "IPK tidak valid" << endl
                 << endl;
        }

    } while (IPK < 0.00 || IPK > 4.00); // Ini buat maksa user ngisi IPK walaupun dia sebelumnya error

    // Input Penghasilan Orang tua
    do
    {                                                         // Kenapa pake do while? ya alasan nya sama kayak diatas sih
        cout << "Masukkan Penghasilan Orang Tua : " << flush; // Meminta Penghasilan Orang Tua
        cin >> penghasilanOrangTua;                           // Input Penghasilan Orang Tua

        if (penghasilanOrangTua < 0)
        {
            cout << "Masa Penghasilan nya minus?" << endl
                 << endl;
        }

    } while (penghasilanOrangTua < 0); // Ini buat maksa user ulang jika salah (dalam artian penghasilan nya minus)

    do
    {
        cout << "Masukkan Jumlah Tanggungan : " << flush;
        cin >> tanggungan;

        if (tanggungan < 0)
        {
            cout << "Tanggungan nya masa minus?";
        }

    } while (tanggungan < 0);

    do
    {
        cout << "Prestasi : " << endl;
        cout << "1. Tidak ada" << endl;
        cout << "2. Fakultas " << endl;
        cout << "3. Universitas " << endl;
        cout << "4. Nasional" << endl;
        cout << "Masukkan pilihan prestasi : " << flush;
        cin >> prestasi;

        if (prestasi < 1 || prestasi > 4)
        {
            cout << "Jawaban tidak valid";
        }

    } while (prestasi < 1 || prestasi > 4);

    // bool cekIPK;

    // if (IPK >= 3.50)
    // {
    //     cekIPK = true;
    // }
    // else
    // {
    //     cekIPK = false;
    // }

    bool cekPenghasilan;

    if (penghasilanOrangTua <= 5000000)
    {
        cekPenghasilan = true;
    }
    else
    {
        cekPenghasilan = false;
    }

    bool cekTanggungan;

    if (tanggungan >= 3)
    {
        cekTanggungan = true;
    }
    else
    {
        cekTanggungan = false;
    }

    bool cekPrestasi; // variabel ini kubikin buat nyatat data si user punya prestasi / tidak

    switch (prestasi)
    {
    case 1:
        cekPrestasi = false;
        break;

    default:
        cekPrestasi = true;
        break;
    }

    string gadapatBeasiswa = "Tidak dapat beasiswa";
    string beasiswaReguler = "Beasiswa Reguler";
    string beasiswaUnggul = "Beasiswa Prestasi unggul";
    string hasilBeasiswa;

    if (cekPenghasilan == true)
    {
        if (cekTanggungan == true)
        {
            if (IPK >= 3.75)
            {
                if (cekPrestasi == true)
                {
                    hasilBeasiswa = beasiswaUnggul;
                }
                else
                {
                    hasilBeasiswa = beasiswaReguler;
                }
            }
            else if (IPK >= 3.50)
            {
                hasilBeasiswa = beasiswaReguler;
            }
            else
            {
                hasilBeasiswa = gadapatBeasiswa;
            }
        }
        else
        {
            hasilBeasiswa = gadapatBeasiswa;
        }
    }
    else
    {
        hasilBeasiswa = gadapatBeasiswa;
    }

    cout << "Status Beasiswa : " << hasilBeasiswa;

    return 0;
}